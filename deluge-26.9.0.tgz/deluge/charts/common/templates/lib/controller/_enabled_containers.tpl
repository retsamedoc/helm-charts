{{/*
Return the enabled containers for a controller.
*/}}
{{- define "retsamedoc.common.lib.controller.enabledContainers" -}}
  {{- $rootContext := .rootContext -}}
  {{- $controllerObject := .controllerObject -}}

  {{- $enabledContainers := dict -}}
  {{- range $name, $container := $controllerObject.containers -}}
    {{- if kindIs "map" $container -}}
      {{- $containerEnabled := true -}}
      {{- if hasKey $container "enabled" -}}
        {{- $containerEnabled = $container.enabled -}}
      {{- end -}}

      {{- if $containerEnabled -}}
        {{- $_ := set $enabledContainers $name $container -}}
      {{- end -}}
    {{- end -}}
  {{- end -}}

  {{- $enabledContainers | toYaml -}}
{{- end -}}
