# juicepassproxy

![Version: 26.9.1](https://img.shields.io/badge/Version-26.9.1-informational?style=flat-square) ![AppVersion: 0.5.1](https://img.shields.io/badge/AppVersion-0.5.1-informational?style=flat-square)

Proxy UDP requests to/from Juicebox EV chargers to MQTT discoverable by Home Assistant

**This chart is not maintained by the upstream project and any issues with the chart should be raised [here](https://github.com/retsamedoc/helm-charts/issues/new/choose)**

## Source Code

* <https://github.com/JuiceRescue/juicepassproxy>

## Requirements

Kubernetes: `>=1.31.0-0`

## Dependencies

| Repository | Name | Version |
|------------|------|---------|
| file://../common | common | 26.9.0 |

## TL;DR

```console
helm repo add retsamedoc https://retsamedoc.github.io/helm-charts/
helm repo update
helm install juicepassproxy retsamedoc/juicepassproxy
```

## Installing the Chart

To install the chart with the release name `juicepassproxy`

```console
helm install juicepassproxy retsamedoc/juicepassproxy
```

## Uninstalling the Chart

To uninstall the `juicepassproxy` deployment

```console
helm uninstall juicepassproxy
```

The command removes all the Kubernetes components associated with the chart **including persistent volumes** and deletes the release.

## Configuration

Read through the [values.yaml](./values.yaml) file. It has several commented out suggested values.
Other values may be used from the [values.yaml](https://github.com/retsamedoc/helm-charts/tree/main/charts/common/values.yaml) from the [common library](https://github.com/retsamedoc/helm-charts/tree/main/charts/common).

Specify each parameter using the `--set key=value[,key=value]` argument to `helm install`.

```console
helm install juicepassproxy \
  --set env.TZ="America/New York" \
    retsamedoc/juicepassproxy
```

Alternatively, a YAML file that specifies the values for the above parameters can be provided while installing the chart.

```console
helm install juicepassproxy retsamedoc/juicepassproxy -f values.yaml
```

## Custom configuration

JuicePass Proxy speaks **UDP on port 8047**. On k3s with the bundled Traefik ingress controller you typically need both of the following (cluster Traefik config is **not** managed by this chart).

### 1. Expose a UDP entrypoint on Traefik (k3s)

Create or patch a `HelmChartConfig` for Traefik so it listens on UDP `8047` (entrypoint name is arbitrary; examples use `juicepass`):

```yaml
apiVersion: helm.cattle.io/v1
kind: HelmChartConfig
metadata:
  name: traefik
  namespace: kube-system
spec:
  valuesContent: |-
    ports:
      juicepass:
        port: 8047
        exposedPort: 8047
        expose:
          default: true
        protocol: UDP
```

Apply this once per cluster (or merge with your existing Traefik `valuesContent`).

### 2. Route that entrypoint to this chart’s Service

Point an `IngressRouteUDP` at the Service this chart creates (name depends on your release; check `kubectl get svc -n <namespace>`):

```yaml
apiVersion: traefik.io/v1alpha1
kind: IngressRouteUDP
metadata:
  name: juicepassproxy-proxy-ingressroute
  namespace: automation   # same namespace as the release
spec:
  entryPoints:
    - juicepass          # must match the Traefik port key above
  routes:
    - services:
        - name: juicepassproxy   # replace with your Service name
          port: 8047
```

You can keep that manifest outside Helm, or render it with this chart via common [`rawResources`](https://github.com/retsamedoc/helm-charts/tree/main/charts/common):

```yaml
rawResources:
  ingressRouteUDP:
    enabled: true
    forceRename: juicepassproxy-proxy-ingressroute
    manifest:
      apiVersion: traefik.io/v1alpha1
      kind: IngressRouteUDP
      spec:
        entryPoints:
          - juicepass
        routes:
          - services:
              - name: juicepassproxy   # replace with your Service name
                port: 8047
```

### Alternatives

- **hostNetwork** / **NodePort** / **LoadBalancer** with `protocol: UDP` if you are not using Traefik for UDP.
- Gateway API **UDPRoute** is supported by the common library when your gateway controller implements it; Traefik’s `IngressRouteUDP` remains the usual path on stock k3s Traefik.

## Values

**Important**: When deploying an application Helm chart you can add more values from the common library chart [here](https://github.com/retsamedoc/helm-charts/tree/main/charts/common)

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| controllers.main.containers.main.env | object | See below | environment variables. |
| controllers.main.containers.main.env.TZ | string | `"UTC"` | Set the container timezone |
| controllers.main.containers.main.image.pullPolicy | string | `"IfNotPresent"` | image pull policy |
| controllers.main.containers.main.image.repository | string | `"ghcr.io/juicerescue/juicepassproxy"` | image repository |
| controllers.main.containers.main.image.tag | string | `"0.5.1"` | image tag |
| controllers.main.strategy | string | `"Recreate"` |  |
| service | object | See values.yaml | Configures service settings for the chart. Normally this does not need to be modified. |

## Support

- Open an [issue](https://github.com/retsamedoc/helm-charts/issues/new/choose)

----------------------------------------------
Autogenerated from chart metadata using [helm-docs v1.14.2](https://github.com/norwoodj/helm-docs/releases/v1.14.2)
